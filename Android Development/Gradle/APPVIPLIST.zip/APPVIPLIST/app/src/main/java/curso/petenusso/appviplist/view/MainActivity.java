package curso.petenusso.appviplist.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import curso.petenusso.appviplist.R;
import curso.petenusso.appviplist.model.Pessoa;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Pessoa pessoa = new Pessoa();
//        primeiro defina uma variavel na classe do componente que voce criou, depois iguale ela com o component no layout usando findViewById()
        EditText editNome;
        EditText editSobrenome;
        EditText editTelefone;
        EditText editCursoDesejado;

        Button btnLimpar;
        Button btnSalvar;
        Button btnFinalizar;


        editNome = findViewById(R.id.editTextNome);
        editSobrenome = findViewById(R.id.editTextSobrenome);
        editCursoDesejado = findViewById(R.id.editTextCursoDesejado);
        editTelefone = findViewById(R.id.editTextTelefone);

        btnFinalizar = findViewById(R.id.btnFinalizar);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnLimpar = findViewById(R.id.btnLimpar);

        pessoa.setNome("Lc");
        pessoa.setCurso("ADS");
        pessoa.setTelefone("1192828383");
        pessoa.setSobrenome("Viana");

        editNome.setText(pessoa.getNome());
        editSobrenome.setText(pessoa.getSobrenome());
        editCursoDesejado.setText(pessoa.getCurso());
        editTelefone.setText(pessoa.getTelefone());

        btnFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Volte sempre", Toast.LENGTH_LONG).show();
                finish();
            }
        });
        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editNome.setText("");
                editSobrenome.setText("");
                editCursoDesejado.setText("");
                editTelefone.setText("");
            }
        });
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editNome.getText().toString().isEmpty() || editSobrenome.getText().toString().isEmpty() || editTelefone.getText().toString().isEmpty() || editCursoDesejado.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Preencha todos os campos!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Dados salvos com sucesso!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}