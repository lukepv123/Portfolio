package curso.petenusso.jokenpoh;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView jogador1;
    ImageView jogador2;

    ImageButton btnPedra;
    ImageButton btnTesoura;
    ImageButton btnPapel;
    MediaPlayer mediaPlayer;
    Animation some, aparece;
    int jogada1, jogada2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        jogador1 = findViewById(R.id.jogador1);
        jogador2 = findViewById(R.id.jogador2);
        btnPedra = findViewById(R.id.btnPedra);
        btnTesoura = findViewById(R.id.btnTesoura);
        btnPapel = findViewById(R.id.btnPapel);
        mediaPlayer = MediaPlayer.create(MainActivity.this,R.raw.alex_play);



        some = new AlphaAnimation(1,0);
        aparece = new AlphaAnimation(1,0);

        some.setDuration(1500);
        aparece.setDuration(100);


    }
    public void clickButton(View view){
        playMusic();
        if(view.getId() == R.id.btnPedra){
            jogador1.setImageResource(R.drawable.pedra);
            jogada1 = 0;

        }
        else if(view.getId() == R.id.btnTesoura){
            jogador1.setImageResource(R.drawable.tesoura);
            jogada1 = 1;
        }
        else if(view.getId() == R.id.btnPapel){
            jogador1.setImageResource(R.drawable.papel);
            jogada1 = 2;
        }

        jogador2.setImageResource(R.drawable.interrogacao);
        jogador2.startAnimation(some);

        some.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                jogador2.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                sortEnemy(); // Mover a função de sortear aqui
                jogador2.startAnimation(aparece); // Iniciar a animação de aparição depois de trocar a imagem
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        aparece.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                jogador2.setVisibility(View.VISIBLE); // Certificar-se de que o ImageView está visível
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                verifyGame(); // Verifica o resultado do jogo após a animação
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });



    }

    public void verifyGame(){
        if(jogada1 == jogada2){
            Toast.makeText(this,"Tied!", Toast.LENGTH_SHORT).show();
        }
        else if ((jogada1 == 0 && jogada2 == 1) || (jogada1 == 1 && jogada2 == 2) || (jogada1 == 2 && jogada2 == 0)){
            Toast.makeText(this, "You win!s", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this,"You lose!" , Toast.LENGTH_SHORT).show();

        }


    }
//pedra 0
//tesoura =1
//papel = 2

    public void sortEnemy(){
        Random r = new Random();
        int numRandom = r.nextInt(3);
        switch (numRandom){
            case 0:jogador2.setImageResource(R.drawable.pedra);jogada2 = 0;break;
            case 1:jogador2.setImageResource(R.drawable.papel);jogada2 = 2; break;
            case 2:jogador2.setImageResource(R.drawable.tesoura);jogada2 = 1; break;
        }

    }

    public  void playMusic(){
        if(mediaPlayer != null){
            mediaPlayer.start();
        }
    }

}