package curso.petenusso.quizz;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    TextView textPergunta;
    RadioButton optionA, optionB, optionC, optionD;
    Button btnOk;

    String[] Perguntas = {
            "Primeira pergunta",
            "Segunda pergunta",
            "Terceira pergunta",
            "Quarta pergunta",
            "Quinta pergunta"
    };

    String[] OpcaoA = {"A primeira", "A segunda", "A terceira", "A quarta", "A quinta"};
    String[] OpcaoB = {"B primeira", "B segunda", "B terceira", "B quarta", "B quinta"};
    String[] OpcaoC = {"C primeira", "C segunda", "C terceira", "C quarta", "C quinta"};
    String[] OpcaoD = {"D primeira", "D segunda", "D terceira", "D quarta", "D quinta"};

    int[] listaRespostas = new int[Perguntas.length];
    int[] listaGabarito = {1, 2, 3, 1, 4};
    int numberQuestion = 0;
    int respostasCorretas = 0;
    boolean isQuizFinished = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        optionA = findViewById(R.id.opcaoA);
        optionB = findViewById(R.id.opcaoB);
        optionC = findViewById(R.id.opcaoC);
        optionD = findViewById(R.id.opcaoD);
        textPergunta = findViewById(R.id.tittle);
        btnOk = findViewById(R.id.btnOk);
        btnOk.setEnabled(false);
        radioGroup = findViewById(R.id.radioGroupQuestions);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (numberQuestion < Perguntas.length) {
                    if (checkedId == R.id.opcaoA) {
                        listaRespostas[numberQuestion] = 1;
                    } else if (checkedId == R.id.opcaoB) {
                        listaRespostas[numberQuestion] = 2;
                    } else if (checkedId == R.id.opcaoC) {
                        listaRespostas[numberQuestion] = 3;
                    } else if (checkedId == R.id.opcaoD) {
                        listaRespostas[numberQuestion] = 4;
                    }
                    btnOk.setEnabled(true);
                }
            }
        });

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isQuizFinished) {
                    if (numberQuestion < Perguntas.length - 1) {
                        atualizaPerguntas();
                    } else {
                        confereResultado();
                        isQuizFinished = true;
                        exibirDialogoReinicio();
                    }
                }
            }
        });

        atualizaPerguntas();
    }

    public void atualizaPerguntas() {
        if (numberQuestion < Perguntas.length) {
            textPergunta.setText(Perguntas[numberQuestion]);
            optionA.setText(OpcaoA[numberQuestion]);
            optionB.setText(OpcaoB[numberQuestion]);
            optionC.setText(OpcaoC[numberQuestion]);
            optionD.setText(OpcaoD[numberQuestion]);
            radioGroup.clearCheck(); // Limpa a seleção anterior
            btnOk.setEnabled(false); // Desativa o botão até que uma opção seja selecionada
            numberQuestion++;
        }
    }

    public void confereResultado() {
        respostasCorretas = 0; // Reinicia a contagem para garantir precisão
        for (int i = 0; i < listaRespostas.length; i++) {
            if (listaRespostas[i] == listaGabarito[i]) {
                respostasCorretas++;
                Log.d("Resultado", "Resposta correta para pergunta " + (i + 1));
            } else {
                Log.d("Resultado", "Resposta incorreta para pergunta " + (i + 1));
            }
        }
        Log.d("Resultado Final", "Total de respostas corretas: " + respostasCorretas);
        textPergunta.setText("Você acertou " + respostasCorretas + " de " + Perguntas.length);
    }

    public void exibirDialogoReinicio() {
        new AlertDialog.Builder(this)
                .setTitle("Reiniciar Quiz")
                .setMessage("Deseja reiniciar o quiz?")
                .setPositiveButton("Sim", (dialog, which) -> reiniciaQuiz())
                .setNegativeButton("Não", ((dialog, which) -> finish()))
                .show();
    }

    public void reiniciaQuiz() {
        // Reinicia as variáveis e o estado do quiz
        numberQuestion = 0;
        respostasCorretas = 0;
        listaRespostas = new int[Perguntas.length];
        isQuizFinished = false;
        btnOk.setEnabled(false);
        atualizaPerguntas();
    }
}
