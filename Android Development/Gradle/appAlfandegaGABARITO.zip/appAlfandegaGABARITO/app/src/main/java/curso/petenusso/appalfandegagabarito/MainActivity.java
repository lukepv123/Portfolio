package curso.petenusso.appalfandegagabarito;

import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    Animation some, aparece;
    int lista1,lista2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        ImageView img_arrow = findViewById(R.id.img_arrow);
        TextView lblTittle = findViewById(R.id.lblTittle);
        img_arrow.setVisibility(View.INVISIBLE);
        lblTittle.setText("Touch to start");

        some = new AlphaAnimation(0, 1);
        aparece  = new AlphaAnimation(1, 0);
        some.setDuration(500);
        aparece.setDuration(500);


        aparece.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                img_arrow.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                img_arrow.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });



    }

    public void onClick(View view){
        TextView lblTittle = findViewById(R.id.lblTittle);
        ImageView img_arrow = findViewById(R.id.img_arrow);
        img_arrow.startAnimation(aparece);

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                img_arrow.startAnimation(some);

            }
        }, 1000);

        if(lista1 <= lista2){
            lblTittle.setText("go to the left");
            img_arrow.setScaleX(1f);
            lista1++;
            Toast.makeText(MainActivity.this, "Lista 1: " + lista1, Toast.LENGTH_LONG).show();
            System.out.print("Lista 1: " + lista1 + "Lista 2: " + lista2);

        }
        else{
            lblTittle.setText("go to the right");
            img_arrow.setScaleX(-1f);
            lista2++;
            Toast.makeText(MainActivity.this, "Lista 2: " + lista2, Toast.LENGTH_SHORT).show();
            System.out.print("Lista 1: " + lista1 + "Lista 2: " + lista2);

        }
    }
}