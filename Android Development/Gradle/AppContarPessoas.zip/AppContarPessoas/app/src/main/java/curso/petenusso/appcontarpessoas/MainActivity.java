package curso.petenusso.appcontarpessoas;

import android.os.Bundle;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    Button btnAddWoman, btnAddMan, btnReset;
    TextView txtTotalPeople;

public  void atualizeTxtTotalofPeople(){
    String quantMan = btnAddMan.getText().toString();
    String quantWoman = btnAddWoman.getText().toString();

    String[] splitMan = quantMan.split("Man: ");
    String[] splitWoman = quantWoman.split("Woman: ");

    int countMan = Integer.parseInt(splitMan[1]);
    int countWoman = Integer.parseInt(splitWoman[1]);

    int sum = countMan + countWoman;
    txtTotalPeople.setText("Total of People: " + sum);

}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtTotalPeople = findViewById(R.id.txtTotalPeople);
        btnAddMan = findViewById(R.id.btnAddMan);
        btnAddWoman = findViewById(R.id.btnAddWoman);
        btnReset = findViewById(R.id.btnReset);

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnAddMan.setText("Man: 0");
                btnAddWoman.setText("Woman: 0");
                txtTotalPeople.setText("Total of People: 0");
            }
        });


        btnAddWoman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String quantWoman = btnAddWoman.getText().toString();
                String[] cortar_numero = quantWoman.split(": ");
                int count = Integer.parseInt(cortar_numero[1]);
                count++;
                btnAddWoman.setText("Woman: " + count);
                atualizeTxtTotalofPeople();
            }
        });
        btnAddMan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String quantMan = btnAddMan.getText().toString();
                String[] cortar_numero = quantMan.split("Man: ");
                int count = Integer.parseInt(cortar_numero[1]);
                count++;
                btnAddMan.setText("Man: " + count);
                atualizeTxtTotalofPeople();
            }
        });

    }
}